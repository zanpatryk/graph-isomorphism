#ifndef AAC_UTILS_H
#define AAC_UTILS_H

char *trim_inplace(char *s);

#endif //AAC_UTILS_H